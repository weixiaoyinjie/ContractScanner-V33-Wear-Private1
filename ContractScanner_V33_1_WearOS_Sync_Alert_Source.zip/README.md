# 合约扫描器 V33.1 · EarlyFlow + Wear OS 同步/目标价格提醒

以用户提供的 **ContractScanner_V32_1_AllCoins_24h_DailyK.zip** 为完整母版，保留原版布局、列、弹窗、按钮和快捷导航；原APK内核心网页资源已核对与上传ZIP完全一致。

## Android身份

- 应用名称：**合约扫描器·V33资金引擎**
- `applicationId`: **`com.contractresearch.scannerv33.earlyflow`**
- `namespace`: `com.contractresearch.flowplusminute`（保留原有 Java 类名以避免破坏代码，不影响并行安装）
- `versionCode`: `3302`
- `versionName`: `33.1-wear-link`
- 原 V32.1 App 不会被覆盖，两款 App 各自保存 API Key、设置与研究数据。

## 不变的界面功能

1. **每一行的“价格24h”涨跌数字均带 `data-k="1d"`，点击打开该币最近90根UTC日K蜡烛图**；BTC和所有其他已扫描币一样有效。
2. 点击价格5m/15m数值对应K线，OI5m/OI15m对应OI曲线，CVD对应CVD图。
3. 原5m资金+、1m资金预警、AI单币分析、批量复核、结构复查、追踪、BTC防御、风险计划、JSON导出、Binance App启动和快速返回定位都保留。
4. MainActivity.java仅增补Wear OS同步桥接，保留原Android Keystore、Coinalyze限额保护、Android资产加载、原通知与导出行为。

## 已实际修改的筛选引擎

| 范围 | 改动 | 目的与边界 |
|---|---|---|
| P0 | 首批市场扫描通过 Binance 批量24h成交额/价格振幅/涨幅排序，BTC置顶；全部合格USDT永续仍照常扫描 | 优先研究相对冷静、流动性可用的币，不因排序影响主列表功能 |
| P0 | 网络请求支持超时、一次重试、429/5xx冷却；OI历史检查时间戳、连续的5m区间与最大数据延迟 | 避免间断/过期OI被误当连续仓位变化 |
| P0 | Coinalyze 5m前置15m过滤在最终取前8之前执行，候选预选池从10扩大至30 | 防止前排已过热币挤占剩余位置 |
| P0 | Coinalyze 5m / 15m / OHLCV检查已收盘数据相邻时间间隔、加强新鲜度标准 | 不把缺失区间拼接成资金持续性；延迟数据只作观察 |
| P0 | Coinalyze资金强度比较使用成交差额/总成交额的相对强度，删除15m OI双重加分 | 减少单纯放量导致的错误偏差及同一指标重复记分 |
| P1 | 基础扫描时动态优先级；扫描后每45秒小批量复查最多8个高优先级币 | 不必为观察重点候选而重新跑完整市场 |
| P1 | 对比连续两次批量24h ticker 的价格快照，最多引入2个新的温和变化币进入定时复查队列 | 增加新出现价格变化的候选发现，不把滚动24h交易量差额冒充1m成交量 |
| P2 | 1m Coinalyze复核每次4个币；前两席优先5m-OI候选，其余优先温和价格+活跃度候选 | 不再只能从旧5m OI排名前4中挑选1m候选 |
| P2 | 每60秒对重点池最多8币读取 Binance `/fapi/v1/openInterest` 的真实时间戳OI快照 | 建立约1m/3m OI变化的本机观察序列；数据不足直接保持不可用，不伪造历史 |

**风险提示**：优先级分数不代表胜率或入场建议。OI只代表仓位变化，不直接确定方向。所有市场数据必须在手机上实际联网验证。应用不自动下单。

## 运行与API条件

- Binance基础扫描必须能访问 `fapi.binance.com`，使用 `/fapi/v1/exchangeInfo`、批量24h、`klines` 和 `/futures/data/openInterestHist` 等公开端点。
- 实时OI观察使用 `/fapi/v1/openInterest?symbol=...`；每个交易对按观察周期请求。首次运行需要累积足够时间戳样本，不能立即得到3分钟OI增速。
- 原Coinalyze 1m和5m资金增强模块仍需用户自行在App内部输入自己的Coinalyze Key；原原生限额仍然存在（每次合并请求按币数消耗配额）。
- 原OpenAI AI分析功能仍需用户自己的API Key，绝不写在ZIP或源码中。
- App仅在前台的可见WebView中定时跟踪。被系统暂停、断网、接口限流或退出App后，不会继续后台扫描。
- 全市场扫描仍需要逐币请求；此次优先优化最早发现与候选维护，**并未实现全市场实时WebSocket订阅或经实盘验证的盈利率提升**。
- `GET /futures/data/openInterestHist` 官方最小5m粒度；本App采集的分钟OI是独立定时的当前OI快照，不是该历史接口的1m数据。

## 构建独立APK（GitHub Actions）

建议新建**私有仓库**，保护策略代码，例如 `ContractScanner-V33-Wear-Private`。

1. 在 https://github.com/new 创建空的私有仓库。
2. 在电脑或手机中**先解压本ZIP**，将根目录内 `app/`、`wear/`、`tests/`、`.github/`、`build.gradle`、`settings.gradle`、`gradle.properties` 和 `README.md` 上传到仓库根目录。不要把ZIP作为唯一文件上传。
3. GitHub → **Actions** → **Build Android APK** → **Run workflow**，或直接push到`main`分支。
4. 等流程成功后在 Artifacts 分别下载 **`ContractScanner-V33-1-Phone-APK`**（其中 `app-debug.apk` 装手机）和 **`ContractScanner-V33-1-Wear-APK`**（其中 `wear-debug.apk` 装手表）。两份APK必须来自同一次编译、使用同一个签名。手机端与V32.1共存，但会尝试升级原V33。

Actions使用Android SDK 35、Java 17、Gradle 8.9；先执行以下全部Node.js测试，再调用 `gradle :app:assembleDebug`。

```bash
node tests/core.test.js
node tests/minute.test.js
node tests/quick-nav.test.js
node tests/engine-v33.test.js
node tests/ui-regression.test.js
node tests/wear-link.test.js
```

## 已验证与尚未验证

- 已验证：原上传ZIP与APK的 `index.html`、`minute-extension.js`、`quick-nav.js` 字节一致；上述全部五组Node回归测试通过；所有脚本可通过语法分析；24h数字→日K的代码路径仍在。
- 尚未验证：本环境不含Android SDK或Gradle，未编出APK；也不能模拟真实Binance和Coinalyze联网结果以及在真机测量发现延迟/误报率。请使用Actions构建并在手机实测。


## V33.1 新增：手机同步到 Wear OS 手表

### 手机端：只增一个按钮

- 每个币种最右侧在 `结构复查` 与 `🤖 AI分析` 之间新增 `⌚ 手表`。
- 单击选中币种后，Android 原生层使用 Google Play services Data Layer 将**币种代码 + 当时的只读扫描指标 + 数据时间戳**写入 `/scanner/watch/selected`，并设置 urgent。
- 原5m复查、结构复查、AI、全部24h日K、币安跳转、风险功能和核心筛选引擎逻辑没有更改；按钮行原本就是横向可滑动布局，屏幕较窄时可以横向滑动寻找按钮。
- 手机响应「已发送」只表示本机的数据项已提交以及检测到配对节点，**不等于手表已经实际收到或刷新**。无手表在线时可显示「已保存同步数据，恢复连接后同步」。
- 不向手表同步 API 密钥、仓位、订单或账户凭证。两端必须是**相同的 Android applicationId + 同一签名证书**；手表配对系统需支持 Google Play services Wearable Data Layer。

### 手表端：Wear OS 独立安装 APP

- 手表主界面使用紧凑原生 Android UI，支持最近同步的12个币切换；展示最近手机快照，随后独立联网读取 Binance USDT-M 永续公开行情。
- 实时数据显示：最新价、5m/15m/24h价格变化、5m/15m OI变化、OI规模、主动买5m、CVD动能、BTC5m；提供手表端5m/15m同轴简化结构图，包含K线、成交量、时间戳匹配的OI曲线，触摸可看收盘/成交量/OI。
- 5m/15m价格使用最近1m价格收盘基准；OI使用5分钟历史快照的最近、前一及前三个有效相邻时点。CVD动能沿用手机公式：**相邻两个已收盘5m K线净主动成交强度的百分点差**，不宣称是逐笔累计CVD。
- 历史 OI 时间戳不连续/过期则显示 `—`，不连结不存在的OI走势。手表获取失败显示故障且**保留手机旧快照但不伪装实时**。
- 手表界面可手动刷新，并在页面前台打开时约每60秒刷新。手表需要能访问 Binance 公共接口；手机并不替手表维持持续行情链路。

### 手表端：目标价提醒

1. 先在手机点 `⌚ 手表` 同步目标币，并在 Wear OS 端启动 APP。
2. 在手表输入 USDT 目标价，选择 `≥ 达到或高于` 或 `≤ 达到或低于`，点击 `🔔 保存并开始提醒`。
3. 第一次请允许手表 APP 发送通知；手表启动前台监测服务（会有持续监测通知），约每30秒通过 Binance `/fapi/v1/ticker/price` 获取最新成交价格。
4. 触及条件时，手表本机发送高优先级通知并振动，自动删除本币单次提醒。最多同时6币，可取消任意币的提醒；所有提醒删除后停止监测服务。

**提醒不是交易所止损/止盈订单，也不是实时逐笔订阅。** 短暂触价后在30秒轮询间隔内返回的行情可能漏报；手表断网、后台策略、省电模式、关闭通知、系统回收或前台服务时长限制也可能影响通知。目标价提醒不应作为唯一风险保险丝；请继续在交易所设置相应的止损单。

### 安装与签名注意

- 新版手机 `applicationId` 保持 `com.contractresearch.scannerv33.earlyflow`，`versionCode` 3302；和原V32.1并存，但会替换已装V33（若签名相同）。
- 若原V33为另一仓库生成的调试签名，覆盖安装可能出现「签名不一致」。**不要直接卸载前一版**：先从旧版导出研究数据、保存所需设置。卸载会清除私有本地记录/密钥，再安装新包并重新设置。
- 通过 Wear OS 的无线调试 + `adb pair` / `adb connect` / `adb install -r wear-debug.apk` 安装手表 APK，或使用你已有的 Wear OS 应用安装方式。手机安装 `app-debug.apk`。
- 若后续迭代需要保留本地数据，应对**手机和手表**使用稳定、相同的签名证书，不要依赖每次自动生成的随机 debug keystore。

### 当前验证范围

- 已验证：上传的 V33 ZIP 中 `index.html`、筛选引擎和复查资源，与所附原 `app-debug.apk` 内对应资源字节完全一致；修改后的全部 6 组 Node 回归测试通过；两端 Java 源码的语法和静态结构另行检查。
- **本运行环境没有 Android SDK/Gradle，未能本地生成或真机测试 APK**。需要 GitHub Actions 实际编译，再在你的具体手表上测试 Google Play 服务、后台监测、通知权限、Binance网络以及圆形屏幕排版。当前工程属于**可供编译/实测的源码版本**，不是已经真机验证的正式发行版。
