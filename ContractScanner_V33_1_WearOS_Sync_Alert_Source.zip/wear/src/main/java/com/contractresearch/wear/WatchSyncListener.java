package com.contractresearch.wear;

import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.WearableListenerService;

/** Receives new selected coins even if the watch UI is not currently open. */
public final class WatchSyncListener extends WearableListenerService {
    static final String PATH="/scanner/watch/selected";
    @Override public void onDataChanged(DataEventBuffer events){
        for(DataEvent e:events){
            if(e.getType()!=DataEvent.TYPE_CHANGED||!PATH.equals(e.getDataItem().getUri().getPath()))continue;
            try{
                DataMap map=DataMapItem.fromDataItem(e.getDataItem()).getDataMap();
                WatchStore.receive(this,map.getString("symbol",""),map.getString("snapshot",""),map.getLong("updatedAt"));
            }catch(Exception ignored){}
        }
    }
}
