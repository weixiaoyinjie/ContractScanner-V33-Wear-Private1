package com.contractresearch.wear;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** User-started foreground service: public price reads while alerts exist.
 * Best effort, not a tick feed. If the OS stops the process, immediate notification isn't guaranteed.
 */
public final class PriceAlertService extends Service {
    private static final String ACTIVE="watch_price_monitor", TRIGGER="watch_price_hit";
    private static final int FOREGROUND_ID=7001;
    private static final long INTERVAL=30_000;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private boolean checking=false;
    private final Runnable cycle=this::tick;
    @Override public IBinder onBind(Intent i){return null;}
    @Override public void onCreate(){super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(ACTIVE,"价格监测运行中",NotificationManager.IMPORTANCE_LOW));
        NotificationChannel alerts=new NotificationChannel(TRIGGER,"目标价已达到",NotificationManager.IMPORTANCE_HIGH);
        alerts.enableVibration(true);nm.createNotificationChannel(alerts);
    }
    private Notification monitoringNotification(){
        Intent open=new Intent(this,WatchActivity.class);
        PendingIntent p=PendingIntent.getActivity(this,800,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        int count=WatchStore.alerts(this).size();
        return new Notification.Builder(this,ACTIVE).setSmallIcon(R.drawable.ic_watch)
            .setContentTitle("合约目标价监测").setContentText("正在监测 "+count+" 个币 · 约30秒一次")
            .setContentIntent(p).setOngoing(true).build();
    }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        Notification n=monitoringNotification();
        if(Build.VERSION.SDK_INT>=29)startForeground(FOREGROUND_ID,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        else startForeground(FOREGROUND_ID,n);
        handler.removeCallbacks(cycle);handler.post(cycle);
        return START_STICKY;
    }
    private void tick(){
        if(checking)return;
        List<WatchStore.PriceAlert> alerts=WatchStore.alerts(this);
        if(alerts.isEmpty()){stopSelf();return;}
        checking=true;
        worker.execute(()->{
            try{
                for(WatchStore.PriceAlert alert:alerts){
                    // Check for deletion / replacement to avoid a stale alert firing.
                    WatchStore.PriceAlert current=WatchStore.alert(this,alert.symbol);
                    if(current==null||current.target!=alert.target||current.atOrAbove!=alert.atOrAbove)continue;
                    try{
                        double last=WatchMetrics.livePrice(alert.symbol);
                        boolean reached=current.atOrAbove?last>=current.target:last<=current.target;
                        if(reached){
                            WatchStore.PriceAlert latest=WatchStore.alert(this,current.symbol);
                            if(latest!=null&&latest.target==current.target&&latest.atOrAbove==current.atOrAbove){
                                WatchStore.removeAlert(this,current.symbol);
                                sendReached(current,last);
                            }
                        }
                    }catch(Exception ignored){/* Network failure: never fabricate a price hit. */}
                }
            }finally{
                handler.post(()->{
                    checking=false;
                    if(WatchStore.alerts(this).isEmpty()){stopSelf();return;}
                    getSystemService(NotificationManager.class).notify(FOREGROUND_ID,monitoringNotification());
                    handler.postDelayed(cycle,INTERVAL);
                });
            }
        });
    }
    private void sendReached(WatchStore.PriceAlert a,double observed){
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)return;
        PendingIntent open=PendingIntent.getActivity(this,Math.abs(a.symbol.hashCode()),
            new Intent(this,WatchActivity.class).putExtra("symbol",a.symbol),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String base=a.symbol.replace("USDT","");
        String direction=a.atOrAbove?"≥":"≤";
        String msg="目标 "+direction+" "+WatchMetrics.price(a.target)+" · 最新价 "+WatchMetrics.price(observed);
        Notification n=new Notification.Builder(this,TRIGGER).setSmallIcon(R.drawable.ic_watch)
            .setContentTitle(base+" 已触达设定价格").setContentText(msg)
            .setStyle(new Notification.BigTextStyle().bigText(msg)).setContentIntent(open)
            .setAutoCancel(true).setCategory(Notification.CATEGORY_ALARM).setPriority(Notification.PRIORITY_HIGH).build();
        getSystemService(NotificationManager.class).notify(Math.abs(a.symbol.hashCode())%100000+10000,n);
        try{
            Vibrator vibrator=(Vibrator)getSystemService(Context.VIBRATOR_SERVICE);
            if(vibrator!=null&&vibrator.hasVibrator())vibrator.vibrate(VibrationEffect.createWaveform(new long[]{0,180,120,240},-1));
        }catch(Exception ignored){}
    }
    @Override public void onDestroy(){handler.removeCallbacks(cycle);worker.shutdownNow();super.onDestroy();}
    // Android 15+ may enforce foreground service dataSync duration limits.
    @Override public void onTimeout(int startId,int fgsType){stopSelf();}
}
