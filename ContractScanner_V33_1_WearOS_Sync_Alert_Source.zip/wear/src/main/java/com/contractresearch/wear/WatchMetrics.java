package com.contractresearch.wear;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.ArrayList;
import java.util.List;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Locale;
import java.math.BigDecimal;

/** Public Binance USDT-M perpetual endpoints; no API key and no trading capability. */
final class WatchMetrics {
    private static final String BASE="https://fapi.binance.com";
    static class Result {
        String symbol;
        double price=Double.NaN,p5=Double.NaN,p15=Double.NaN,p24=Double.NaN,
               oi5=Double.NaN,oi15=Double.NaN,oiUsd=Double.NaN,buy5=Double.NaN,cvd5=Double.NaN,btc5=Double.NaN;
        long updatedAt,oiUpdatedAt;
        String note="";
        List<Candle> five=new ArrayList<>(),fifteen=new ArrayList<>();
    }
    static class Candle {
        long start,end;
        double open,high,low,close,volume,oi=Double.NaN;
        int members=1;
    }
    static List<Candle> candles(JSONArray k,JSONArray history,long now){
        List<Candle> out=new ArrayList<>();
        for(int i=0;i<k.length();i++){
            JSONArray a=k.optJSONArray(i);if(a==null)continue;
            Candle c=new Candle();c.start=(long)num(a,0);c.end=(long)num(a,6);
            c.open=num(a,1);c.high=num(a,2);c.low=num(a,3);c.close=num(a,4);c.volume=num(a,5);
            if(c.end>=now||!Double.isFinite(c.open)||!Double.isFinite(c.close)||!Double.isFinite(c.volume))continue;
            // Nearest historical OI, only if timestamps genuinely overlap.
            long distance=Long.MAX_VALUE;
            for(int j=0;j<history.length();j++){
                JSONObject item=history.optJSONObject(j);if(item==null)continue;
                long t=item.optLong("timestamp",0),dist=Math.abs(t-c.end);
                if(t>0&&dist<distance){distance=dist;c.oi=item.optDouble("sumOpenInterest",Double.NaN);}
            }
            if(distance>165000||!Double.isFinite(c.oi))c.oi=Double.NaN;
            out.add(c);
        }
        return out;
    }
    static List<Candle> aggregate15(List<Candle> five){
        Map<Long,Candle> groups=new LinkedHashMap<>();
        for(Candle c:five){
            long bucket=c.start/900000L;
            Candle a=groups.get(bucket);
            if(a==null){a=new Candle();a.start=bucket*900000L;a.open=c.open;a.high=c.high;a.low=c.low;a.volume=0;a.members=0;groups.put(bucket,a);}
            a.high=Math.max(a.high,c.high);a.low=Math.min(a.low,c.low);
            a.close=c.close;a.end=c.end;a.volume+=c.volume;a.oi=c.oi;a.members++;
        }
        List<Candle> result=new ArrayList<>();
        for(Candle c:groups.values())if(c.members==3&&c.end>=c.start+900000L-1000)result.add(c);
        return result;
    }
    static String request(String url) throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();
        c.setRequestProperty("Accept","application/json");c.setConnectTimeout(6000);c.setReadTimeout(7000);c.setUseCaches(false);
        try{
            int status=c.getResponseCode();if(status!=200)throw new Exception("行情 HTTP "+status);
            StringBuilder s=new StringBuilder();
            try(InputStream stream=c.getInputStream();BufferedReader reader=new BufferedReader(new InputStreamReader(stream,StandardCharsets.UTF_8))){
                char[] buf=new char[4096];int n;while((n=reader.read(buf))>=0){s.append(buf,0,n);if(s.length()>300_000)throw new Exception("数据过大");}
            }
            return s.toString();
        }finally{c.disconnect();}
    }
    static double livePrice(String symbol) throws Exception {
        if(!WatchStore.validSymbol(symbol))throw new Exception("交易对无效");
        double v=new JSONObject(request(BASE+"/fapi/v1/ticker/price?symbol="+symbol)).optDouble("price",Double.NaN);
        if(!Double.isFinite(v)||v<=0)throw new Exception("价格数据无效");return v;
    }
    static double num(JSONArray k,int idx){return k.optDouble(idx,Double.NaN);}
    private static double pct(double a,double b){return Double.isFinite(a)&&Double.isFinite(b)&&b>0?(a/b-1)*100:Double.NaN;}
    private static JSONArray last(JSONArray a,int offset){return a.optJSONArray(a.length()-offset);}
    static Result load(String symbol) throws Exception{
        if(!WatchStore.validSymbol(symbol))throw new Exception("币种格式无效");
        ExecutorService pool=Executors.newFixedThreadPool(5);
        try{
            Future<JSONArray> k1=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol="+symbol+"&interval=1m&limit=19")));
            Future<JSONArray> k5=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol="+symbol+"&interval=5m&limit=62")));
            Future<JSONArray> oi=pool.submit(()->new JSONArray(request(BASE+"/futures/data/openInterestHist?symbol="+symbol+"&period=5m&limit=62")));
            Future<JSONObject> day=pool.submit(()->new JSONObject(request(BASE+"/fapi/v1/ticker/24hr?symbol="+symbol)));
            Future<JSONArray> btc=pool.submit(()->new JSONArray(request(BASE+"/fapi/v1/klines?symbol=BTCUSDT&interval=1m&limit=7")));
            JSONArray one=k1.get(),five=k5.get(),holds=oi.get(),btcOne=btc.get();JSONObject tick=day.get();
            long now=System.currentTimeMillis();
            if(one.length()<16||five.length()<3||btcOne.length()<6)throw new Exception("K线样本不足");
            JSONArray current=last(one,1),closed=last(five,2),previous=last(five,3);
            if(num(current,6)<now-180_000||num(closed,6)<now-720_000)throw new Exception("K线已经过期");
            Result r=new Result();r.symbol=symbol;r.updatedAt=now;
            r.price=num(current,4);r.p5=pct(r.price,num(last(one,6),4));r.p15=pct(r.price,num(last(one,16),4));
            r.p24=tick.optDouble("priceChangePercent",Double.NaN);
            double q=num(closed,7),t=num(closed,10),qp=num(previous,7),tp=num(previous,10);
            if(q>0&&qp>0){
                r.buy5=t/q*100;
                // Same CLOSED 5m bars and same formula as the V33 phone scanner.
                r.cvd5=((2*t-q)/q-(2*tp-qp)/qp)*100;
            }
            r.btc5=pct(num(last(btcOne,1),4),num(last(btcOne,6),4));
            r.five=candles(five,holds,now);
            r.fifteen=aggregate15(r.five);
            if(holds.length()>=4){
                JSONObject latest=holds.optJSONObject(holds.length()-1);
                JSONObject prior5=holds.optJSONObject(holds.length()-2);
                JSONObject prior15=holds.optJSONObject(holds.length()-4);
                if(latest!=null&&prior5!=null&&prior15!=null){
                    long tt=latest.optLong("timestamp",0),t5=prior5.optLong("timestamp",0),t15=prior15.optLong("timestamp",0);
                    if(tt>0&&now-tt<=720_000&&tt<=now+60000&&Math.abs(tt-t5-300000)<=2000&&Math.abs(tt-t15-900000)<=3000){
                        double o=latest.optDouble("sumOpenInterest",Double.NaN);
                        r.oi5=pct(o,prior5.optDouble("sumOpenInterest",Double.NaN));
                        r.oi15=pct(o,prior15.optDouble("sumOpenInterest",Double.NaN));
                        r.oiUsd=latest.optDouble("sumOpenInterestValue",Double.NaN);
                        r.oiUpdatedAt=tt;
                    }else r.note="OI历史快照过期或存在缺口，OI显示—";
                }
            }else r.note="OI历史数据不足，OI显示—";
            if(!Double.isFinite(r.price)||r.price<=0||!Double.isFinite(r.p5)||!Double.isFinite(r.p15))throw new Exception("价格字段无效");
            return r;
        }finally{pool.shutdownNow();}
    }
    static String price(double x){
        if(!Double.isFinite(x))return "—";
        if(x>=100)return String.format(Locale.US,"%.2f",x);
        if(x>=1)return String.format(Locale.US,"%.4f",x);
        if(x>=.01)return String.format(Locale.US,"%.5f",x);
        if(x>=.0001)return String.format(Locale.US,"%.7f",x);
        return BigDecimal.valueOf(x).stripTrailingZeros().toPlainString();
    }
    static String percent(double x){return Double.isFinite(x)?String.format(Locale.US,"%+.2f%%",x):"—";}
    static String buy(double x){return Double.isFinite(x)?String.format(Locale.US,"%.1f%%",x):"—";}
    static String usd(double x){return Double.isFinite(x)?"$"+String.format(Locale.US,x>=1e9?"%.2fB":x>=1e6?"%.1fM":"%.0f",x>=1e9?x/1e9:x>=1e6?x/1e6:x):"—";}
}
