package com.contractresearch.wear;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

/** Wear-local persistence. Data Layer is a transport, not a durable watch database. */
final class WatchStore {
    private static SharedPreferences prefs(Context c){return c.getSharedPreferences("scanner_wear_v1",Context.MODE_PRIVATE);}
    static boolean validSymbol(String s){return s!=null&&s.matches("[A-Z0-9]{2,24}USDT");}
    static synchronized void receive(Context c,String symbol,String snapshot,long updatedAt){
        if(!validSymbol(symbol)||snapshot==null||snapshot.length()>2500)return;
        try{if(!symbol.equals(new JSONObject(snapshot).optString("symbol")))return;}catch(Exception e){return;}
        ArrayList<String> all=symbols(c);all.remove(symbol);all.add(0,symbol);
        while(all.size()>12)all.remove(all.size()-1);
        JSONArray array=new JSONArray();for(String s:all)array.put(s);
        prefs(c).edit().putString("coins",array.toString()).putString("selected",symbol)
                .putString("snapshot_"+symbol,snapshot).putLong("syncAt_"+symbol,updatedAt).apply();
    }
    static synchronized ArrayList<String> symbols(Context c){
        ArrayList<String> out=new ArrayList<>();
        try{JSONArray j=new JSONArray(prefs(c).getString("coins","[]"));for(int i=0;i<j.length();i++){
            String s=j.optString(i,"");if(validSymbol(s)&&!out.contains(s))out.add(s);
        }}catch(Exception ignored){}return out;
    }
    static String selected(Context c){return prefs(c).getString("selected","");}
    static void select(Context c,String s){if(validSymbol(s))prefs(c).edit().putString("selected",s).apply();}
    static JSONObject snapshot(Context c,String s){try{return new JSONObject(prefs(c).getString("snapshot_"+s,"{}"));}catch(Exception e){return new JSONObject();}}
    static long syncAt(Context c,String s){return prefs(c).getLong("syncAt_"+s,0);}

    static final class PriceAlert {
        final String symbol;
        final double target;
        final boolean atOrAbove;
        PriceAlert(String symbol,double target,boolean atOrAbove){this.symbol=symbol;this.target=target;this.atOrAbove=atOrAbove;}
    }
    static synchronized List<PriceAlert> alerts(Context c){
        ArrayList<PriceAlert> out=new ArrayList<>();
        try{JSONObject all=new JSONObject(prefs(c).getString("alerts","{}"));
            for(java.util.Iterator<String> it=all.keys();it.hasNext();){
                String s=it.next();JSONObject a=all.optJSONObject(s);
                if(a==null||!validSymbol(s))continue;
                double target=a.optDouble("target",Double.NaN);
                if(Double.isFinite(target)&&target>0&&target<1e12)out.add(new PriceAlert(s,target,a.optBoolean("above",true)));
            }
        }catch(Exception ignored){}return out;
    }
    static synchronized PriceAlert alert(Context c,String symbol){for(PriceAlert a:alerts(c))if(a.symbol.equals(symbol))return a;return null;}
    static synchronized void saveAlert(Context c,String symbol,double target,boolean atOrAbove){
        if(!validSymbol(symbol)||!Double.isFinite(target)||target<=0||target>=1e12)return;
        try{JSONObject all=new JSONObject(prefs(c).getString("alerts","{}"));
            all.put(symbol,new JSONObject().put("target",target).put("above",atOrAbove));
            prefs(c).edit().putString("alerts",all.toString()).apply();
        }catch(Exception ignored){}
    }
    static synchronized void removeAlert(Context c,String symbol){
        try{JSONObject all=new JSONObject(prefs(c).getString("alerts","{}"));all.remove(symbol);
            prefs(c).edit().putString("alerts",all.toString()).apply();
        }catch(Exception ignored){}
    }
}
