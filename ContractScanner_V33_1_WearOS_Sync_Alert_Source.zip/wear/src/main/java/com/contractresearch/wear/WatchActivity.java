package com.contractresearch.wear;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import com.google.android.gms.wearable.DataClient;
import com.google.android.gms.wearable.DataEvent;
import com.google.android.gms.wearable.DataEventBuffer;
import com.google.android.gms.wearable.DataMap;
import com.google.android.gms.wearable.DataMapItem;
import com.google.android.gms.wearable.Wearable;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Compact, native Wear OS review UI. No order placement or trading credentials. */
public final class WatchActivity extends Activity implements DataClient.OnDataChangedListener {
    private final int BG=Color.rgb(7,19,32), CARD=Color.rgb(20,42,63), MUTED=Color.rgb(153,174,196), WHITE=Color.rgb(230,242,250);
    private final int GREEN=Color.rgb(69,211,157), RED=Color.rgb(242,117,141);
    private LinearLayout page;
    private TextView title,status,price,alertInfo;
    private final TextView[] values=new TextView[9];
    private EditText targetInput;
    private StructureChartView chart;
    private TextView chartDetail;
    private Button fiveBtn,fifteenBtn;
    private boolean show15=false;
    private Button aboveBtn,belowBtn;
    private boolean above=true,busy=false;
    private String symbol="";
    private WatchMetrics.Result current;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private final ExecutorService network=Executors.newSingleThreadExecutor();
    private int sequence=0;
    private final Runnable periodic=new Runnable(){@Override public void run(){
        String incoming=WatchStore.selected(WatchActivity.this);
        if(WatchStore.validSymbol(incoming)&&!incoming.equals(symbol))setSymbol(incoming,true);
        else if(!busy&&WatchStore.validSymbol(symbol))refresh(false);
        handler.postDelayed(this,60_000);
    }};
    private String incomingFromIntent="";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        incomingFromIntent=getIntent().getStringExtra("symbol");
        makeScreen();
        String first=WatchStore.validSymbol(incomingFromIntent)?incomingFromIntent:WatchStore.selected(this);
        if(WatchStore.validSymbol(first))setSymbol(first,true);
        else status.setText("请在手机扫描器点击 ⌚ 手表，同步币种");
        // Rehydrate selected data item when the watch app is installed after phone sync.
        Wearable.getDataClient(this).getDataItems().addOnSuccessListener(items->{
            try{for(int i=0;i<items.getCount();i++){
                if(WatchSyncListener.PATH.equals(items.get(i).getUri().getPath())){
                    DataMap m=DataMapItem.fromDataItem(items.get(i)).getDataMap();
                    receive(m);
                }
            }}finally{items.release();}
        });
    }
    @Override protected void onResume(){super.onResume();
        Wearable.getDataClient(this).addListener(this);
        handler.removeCallbacks(periodic);handler.postDelayed(periodic,60_000);
        String s=WatchStore.selected(this);
        if(WatchStore.validSymbol(s)&&!s.equals(symbol))setSymbol(s,true);
        updateAlert();
    }
    @Override protected void onPause(){handler.removeCallbacks(periodic);Wearable.getDataClient(this).removeListener(this);super.onPause();}
    @Override protected void onDestroy(){sequence++;network.shutdownNow();super.onDestroy();}

    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout vertical(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout horizontal(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private TextView txt(String text,int size,int color){TextView v=new TextView(this);v.setText(text);v.setTextColor(color);v.setTextSize(size);v.setGravity(Gravity.CENTER_VERTICAL);return v;}
    private Button button(String text){Button v=new Button(this);v.setText(text);v.setTextColor(WHITE);v.setAllCaps(false);v.setTextSize(11);v.setMinHeight(dp(38));v.setMinimumHeight(dp(38));v.setPadding(dp(3),0,dp(3),0);return v;}
    private void add(LinearLayout p,View v,int top){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.topMargin=dp(top);p.addView(v,lp);}
    private void makeScreen(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        page=vertical();page.setPadding(dp(16),dp(12),dp(16),dp(24));scroll.addView(page);setContentView(scroll);
        title=txt("合约复查 · Wear",22,WHITE);title.setGravity(Gravity.CENTER);add(page,title,0);
        price=txt("—",22,GREEN);price.setGravity(Gravity.CENTER);add(page,price,2);
        status=txt("等待手机同步币种",11,MUTED);status.setGravity(Gravity.CENTER);add(page,status,3);
        LinearLayout nav=horizontal();
        Button previous=button("‹ 上一币"),next=button("下一币 ›"),reload=button("↻ 刷新");
        for(Button b:new Button[]{previous,next,reload})nav.addView(b,new LinearLayout.LayoutParams(0,dp(43),1));
        previous.setOnClickListener(v->shift(1));next.setOnClickListener(v->shift(-1));reload.setOnClickListener(v->refresh(true));add(page,nav,7);
        String[] labels={"价格 5m","价格 15m","价格 24h","OI 规模","OI 5m","OI 15m","主动买 5m","CVD 动能","BTC 5m"};
        for(int i=0;i<labels.length;i+=2){LinearLayout line=horizontal();
            for(int j=i;j<Math.min(i+2,labels.length);j++){
                final int index=j;LinearLayout card=vertical();card.setBackgroundColor(CARD);card.setPadding(dp(9),dp(7),dp(7),dp(8));
                TextView name=txt(labels[index],11,MUTED),val=txt("—",16,WHITE);val.setSingleLine(true);
                card.addView(name);card.addView(val);values[index]=val;
                LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(62),1);
                if(j==i+1)lp.leftMargin=dp(6);line.addView(card,lp);
            }add(page,line,6);
        }
        LinearLayout chartTabs=horizontal();fiveBtn=button("5m结构图");fifteenBtn=button("15m结构图");
        chartTabs.addView(fiveBtn,new LinearLayout.LayoutParams(0,dp(43),1));
        chartTabs.addView(fifteenBtn,new LinearLayout.LayoutParams(0,dp(43),1));
        fiveBtn.setOnClickListener(v->{show15=false;showChart();});
        fifteenBtn.setOnClickListener(v->{show15=true;showChart();});
        add(page,chartTabs,11);
        chart=new StructureChartView(this);chart.setOnSelect(b->{if(chartDetail!=null){
            chartDetail.setText("K线收盘 "+WatchMetrics.price(b.close)+" · 量 "+WatchMetrics.price(b.volume)+" · OI "+(Double.isFinite(b.oi)?WatchMetrics.price(b.oi):"未同步"));
        }});
        LinearLayout.LayoutParams chartParams=new LinearLayout.LayoutParams(-1,dp(235));chartParams.topMargin=dp(4);
        page.addView(chart,chartParams);
        chartDetail=txt("触摸图表查看K线、成交量及OI",10,MUTED);add(page,chartDetail,3);
        TextView hint=txt("价格/OI/CVD 需结合判断；无自动开仓。",10,MUTED);hint.setGravity(Gravity.CENTER);add(page,hint,7);
        TextView alarmTitle=txt("目标价格提醒（USDT）",15,WHITE);alarmTitle.setGravity(Gravity.CENTER);add(page,alarmTitle,14);
        targetInput=new EditText(this);targetInput.setHint("输入目标价，如 1.2345");targetInput.setTextColor(WHITE);targetInput.setHintTextColor(MUTED);
        targetInput.setTextSize(16);targetInput.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        targetInput.setSingleLine(true);add(page,targetInput,4);
        LinearLayout directions=horizontal();aboveBtn=button("≥ 达到或高于");belowBtn=button("≤ 达到或低于");
        directions.addView(aboveBtn,new LinearLayout.LayoutParams(0,dp(45),1));directions.addView(belowBtn,new LinearLayout.LayoutParams(0,dp(45),1));
        aboveBtn.setOnClickListener(v->setDirection(true));belowBtn.setOnClickListener(v->setDirection(false));
        setDirection(true);add(page,directions,4);
        Button set=button("🔔 保存并开始提醒");set.setTextSize(13);set.setOnClickListener(v->saveAlert());add(page,set,7);
        Button cancel=button("取消当前币提醒");cancel.setOnClickListener(v->cancelAlert());add(page,cancel,3);
        alertInfo=txt("未设置提醒",11,MUTED);alertInfo.setGravity(Gravity.CENTER);add(page,alertInfo,5);
        TextView foot=txt("提醒由手表独立联网检查，约30秒轮询；断网/省电/系统停服可能延迟或漏报。提醒仅用于研究，不等于止损委托。",10,MUTED);
        add(page,foot,12);
    }
    private void setDirection(boolean isAbove){above=isAbove;aboveBtn.setTextColor(above?GREEN:MUTED);belowBtn.setTextColor(!above?GREEN:MUTED);}
    private void shift(int delta){ArrayList<String> all=WatchStore.symbols(this);if(all.isEmpty()){toast("请先从手机同步币种");return;}
        int pos=all.indexOf(symbol);int next=(pos+delta+all.size())%all.size();
        String selected=all.get(next);WatchStore.select(this,selected);setSymbol(selected,true);
    }
    private void setSymbol(String s,boolean fetch){
        if(!WatchStore.validSymbol(s))return;
        boolean changed=!s.equals(symbol);symbol=s;current=null;
        if(changed){busy=false;show15=false;}
        if(changed)sequence++;
        title.setText(s.replace("USDT","")+" · 结构复查");
        price.setText("—");
        showChart();
        status.setText("手机快照（尚未获取实时数据）");
        JSONObject o=WatchStore.snapshot(this,s);
        showValues(o.optDouble("p5",Double.NaN),o.optDouble("p15",Double.NaN),o.optDouble("p24",Double.NaN),
            o.optDouble("oiUsd",Double.NaN),o.optDouble("oi5",Double.NaN),o.optDouble("oi15",Double.NaN),
            o.optDouble("buy5",Double.NaN),o.optDouble("cvd5",Double.NaN),Double.NaN);
        double saved=o.optDouble("cur",Double.NaN);if(Double.isFinite(saved))price.setText("参考价 "+WatchMetrics.price(saved));
        long t=o.optLong("sampledAt",0);if(t>0){status.setText("手机快照 "+stamp(t)+" · 等待手表刷新");}
        updateAlert();if(fetch)refresh(false);
    }
    private String stamp(long ms){return new SimpleDateFormat("HH:mm:ss",Locale.CHINA).format(new Date(ms));}
    private void showValues(double p5,double p15,double p24,double usd,double oi5,double oi15,double buy,double cvd,double btc){
        double[] data={p5,p15,p24,usd,oi5,oi15,buy,cvd,btc};
        for(int i=0;i<values.length;i++){
            if(values[i]==null)continue;
            String s=i==3?WatchMetrics.usd(data[i]):i==6?WatchMetrics.buy(data[i]):WatchMetrics.percent(data[i]);
            values[i].setText(s);
            values[i].setTextColor(i==3?WHITE:i==6?(Double.isFinite(data[i])?(data[i]>=50?GREEN:RED):WHITE):
                Double.isFinite(data[i])?(data[i]>0?GREEN:data[i]<0?RED:WHITE):WHITE);
        }
    }
    private void refresh(boolean user){
        if(busy){if(user)toast("正在获取最新数据");return;}
        if(!WatchStore.validSymbol(symbol)){if(user)toast("先在手机同步币种");return;}
        busy=true;final String checked=symbol;final int seq=++sequence;
        status.setText("正在读取 Binance 公开行情…");
        network.execute(()->{
            try{WatchMetrics.Result r=WatchMetrics.load(checked);
                runOnUiThread(()->{if(seq!=sequence||!checked.equals(symbol))return;
                    busy=false;current=r;price.setText(WatchMetrics.price(r.price)+" USDT");
                    status.setText("手表实时读取 "+stamp(r.updatedAt)+(r.note.isEmpty()?"":" · "+r.note));
                    showValues(r.p5,r.p15,r.p24,r.oiUsd,r.oi5,r.oi15,r.buy5,r.cvd5,r.btc5);
                    showChart();
                });
            }catch(Exception ex){runOnUiThread(()->{if(seq!=sequence)return;
                busy=false;status.setText("获取失败："+ex.getMessage()+" · 保留手机快照");
            });}
        });
    }
    private void showChart(){
        if(chart==null)return;
        fiveBtn.setTextColor(show15?MUTED:GREEN);fifteenBtn.setTextColor(show15?GREEN:MUTED);
        if(current==null){chart.data(null);if(chartDetail!=null)chartDetail.setText("等待手表实时K线/OI数据");return;}
        chart.data(show15?current.fifteen:current.five);
    }
    private void updateAlert(){if(alertInfo==null)return;
        WatchStore.PriceAlert a=WatchStore.alert(this,symbol);
        if(a==null){alertInfo.setText("当前币无提醒 · 活跃提醒 "+WatchStore.alerts(this).size()+" 个");targetInput.setText("");}
        else{alertInfo.setText("监测中："+(a.atOrAbove?"≥":"≤")+WatchMetrics.price(a.target)+" · 全部 "+WatchStore.alerts(this).size()+" 个");
            targetInput.setText(java.math.BigDecimal.valueOf(a.target).stripTrailingZeros().toPlainString());setDirection(a.atOrAbove);}
    }
    private void saveAlert(){if(!WatchStore.validSymbol(symbol)){toast("请先同步币种");return;}
        double target;
        try{target=Double.parseDouble(targetInput.getText().toString().trim());}
        catch(Exception e){toast("请输入有效的目标价格");return;}
        if(!Double.isFinite(target)||target<=0||target>=1e12){toast("目标价格必须大于0");return;}
        if(WatchStore.alert(this,symbol)==null&&WatchStore.alerts(this).size()>=6){toast("最多同时监测6个币，请先取消旧提醒");return;}
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},401);
            toast("请允许通知后再次点击保存，避免到价却无法提醒");return;
        }
        WatchStore.saveAlert(this,symbol,target,above);
        try{Intent in=new Intent(this,PriceAlertService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(in);else startService(in);
            toast(symbol.replace("USDT","")+" 提醒已启用");
        }catch(Exception e){WatchStore.removeAlert(this,symbol);toast("无法启动持续监测："+e.getMessage());}
        updateAlert();
    }
    private void cancelAlert(){if(!WatchStore.validSymbol(symbol))return;WatchStore.removeAlert(this,symbol);
        if(WatchStore.alerts(this).isEmpty())stopService(new Intent(this,PriceAlertService.class));
        updateAlert();toast("已取消当前币提醒");
    }
    private void toast(String msg){Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();}
    private void receive(DataMap m){WatchStore.receive(this,m.getString("symbol",""),m.getString("snapshot",""),m.getLong("updatedAt"));
        String selected=WatchStore.selected(this);
        if(WatchStore.validSymbol(selected))setSymbol(selected,true);
    }
    @Override public void onDataChanged(DataEventBuffer events){for(DataEvent e:events){
        if(e.getType()!=DataEvent.TYPE_CHANGED||!WatchSyncListener.PATH.equals(e.getDataItem().getUri().getPath()))continue;
        try{DataMap map=DataMapItem.fromDataItem(e.getDataItem()).getDataMap();
            runOnUiThread(()->receive(map));
        }catch(Exception ignored){}
    }}
}
